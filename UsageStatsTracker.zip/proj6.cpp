#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <vector>

using namespace std;

/* Evan Foote Project 6: Word Number and Character usage statistics
*  Due Tues, July 27 (100 pts)
*  Note: No Late submissions
*  makefile : proj6.x 
*  Output Specifications : Num word, number, and char appears, ten most used, 
*  only lowercase, descending order, breaking ties when 2 chars occur same, ascii value
*  will be used to decide, two words or nums occur same, earlier in input is more frequent
*/

//ABET Assessment
//This is our assignment that will satisfy the ABET assessment requirement that students 
//in this course are able to do algorithm complexity analysis on chosen solutions to problems.
		
void outputWords(std::map<string, pair<int, int>> &map, int count);	//Will display the "Top Ten" Words
void outputNumbers(std::map<string, pair<int, int>> &map, int count); //Will display the "Top Ten" Numbers		
void outputChar(std::map<string, pair<int, int>> &map, int count); //Will display the "Top Ten" Characters

void outputWords(map<string, pair<int, int>> &map, int count){
	int tracking=0;
	
	std::map<string, pair<int, int>>::iterator tmp=map.begin();
	
	if(count > 10){count=10;}
	
	if(count > map.size()){count=map.size();}
	
	cout<<"Total number of different words: "<<map.size()<<" and, "<<count<<" most used characters:"<<endl;
	
	for(int i=0; i < count; i++){
		int targetedData=0; //Initialize as 0 so the loop will run 
		
		for(std::map<string, pair<int, int>>::iterator iter=map.begin(); iter != map.end(); ++iter){
			if(iter->second.first > targetedData || (iter-> second.first == targetedData && (iter->second.second < tmp->second.second))){
				targetedData=iter->second.first;
				tmp=iter;
				tracking++;
			}
		}
		cout<<"# "<<i<<": "<<tmp->first<<"		"<<targetedData<<endl;
		map.erase(tmp); 
	}
}
	
void outputNumbers(map<string, pair<int, int>> &map, int count){
	int tracking=0;
	
	std::map<string, pair<int, int>>::iterator tmp=map.begin();
	
	if(count > 10){count=10;}
	
	if(count > map.size()){count=map.size();}
	
	cout<<"Total number of different words: "<<map.size()<<" and, "<<count<<" most used characters:"<<endl;
	for(int i=0; i < count; i++){
		int targetedData=0;	//Initialize as 0 so the loop will run 
		
		for(std::map<string, pair<int, int>>::iterator iter=map.begin(); iter != map.end(); ++iter){
			if(iter->second.first > targetedData || (iter->second.first == targetedData && (iter->second.second < tmp->second.second))){
				targetedData=iter->second.first;
				tmp=iter;
				tracking++;
			}
		}
		cout<<"# "<<i<<": "<<tmp->first<<"		"<<targetedData<<endl;
		map.erase(tmp); //Clears the count
	}
}

void outputChar(map<string, pair<int, int>> &map, int count){
	int tracking=0;
	
	std::map<string, pair<int, int>>::iterator tmp=map.begin();
	
	if(count > 10){count=10;}
	
	if(count > map.size()){count=map.size();}
	
	cout<<"Total number of different words: "<<map.size()<<" and, "<<count<<" most used characters:"<<endl;
	
	for(int i=0; i < count; i++){
		int targetedData=0;	//Initialize as 0 so the loop will run 
		for(std::map<string, pair<int, int> >::iterator iter=map.begin(); iter != map.end(); ++iter)
		{
			if(iter->second.first > targetedData || (iter->second.first == targetedData && (iter->second.second < tmp->second.second)))
			{
				targetedData=iter->second.first;
				tmp=iter;
				tracking++;
			}
		}
		cout<<"# "<<i<<": ";
		if(tmp->first == "\t"){cout<<"\\t"<<"		"<<targetedData<<endl;}
		else if(tmp->first == "\n"){cout<<"\\n"<<"		"<<targetedData<<endl;}
		else{cout<<tmp->first<<"		"<<targetedData<<endl;}
		map.erase(tmp); // Clears the count
	}
	
}

int main(){	
	int wordCount=0;	// Count # of words
	int numCount=0;	    // Count # of ints
	int count=0;		// Count # of chars
	char chr;			// Reads char input
	string word;		// Stores each word
	string number;		// Stores each number
	string character;	// Stores each char	
	
	std::map<string, pair<int, int>> wordMap; // map of words
	std::map<string, pair<int, int>> numMap;  // map of numbers
	std::map<string, pair<int, int>> chrMap;  // map of chars
	
	while(!cin.eof()){
		count++;
		cin.get(chr);		// Storing each character input
		character += chr;	// char counter for the loop
		
		if(cin.fail() == true){
			if(word.size() >= 1){
				if(wordMap.find(word) == wordMap.end()){
					wordMap.insert(make_pair(word, make_pair(1, count)));
					wordCount++;
				}else{
					++wordMap[word].first;
				}
				word=""; // clear counter
			}else if(number.size() >= 1){
				if(numMap.find(number) == numMap.end()){
					numMap.insert(make_pair(number, make_pair(1, count)));
					numCount++;
				}else{
					++numMap[number].first;
				}
				number=""; //clear counter
			}
			break;	//Cleared Segmentation Fault
		}else if(isdigit(chr) != 0){
			number += chr;
			
			if(word.size() >= 1){
				if(wordMap.find(word) == wordMap.end()){
					wordMap.insert(make_pair(word, make_pair(1, count)));
					wordCount++;
				}else{
					++wordMap[word].first;
				}
				word=""; //Clears the count
			}
		}else if(isalpha(chr) != 0){
			word += tolower(chr);
			
			if(number.size() >= 1){
				if(numMap.find(number) == numMap.end()){
					numMap.insert(make_pair(number, make_pair(1, count)));
					numCount++;
				}else{
					++numMap[number].first;
				}
				number=""; //Clears the count
			}
		}else{
			if(word.size() >= 1){
				if(wordMap.find(word) == wordMap.end()){
					wordMap.insert(make_pair(word, make_pair(1, count)));
					wordCount++;
				}else{
					++wordMap[word].first;
				}
				word=""; //Clears the count
			}
			else if(number.size() >= 1){
				if(numMap.find(number) == numMap.end()){
					numMap.insert(make_pair(number, make_pair(1, count)));
					numCount++;
				}else{
					++numMap[number].first;
				}
				number=""; //Clears the count
			}
		}
		++chrMap[character].first;
		character=""; // Clears the count
	}
	
	outputChar(chrMap, count);			// display Character data
	outputWords(wordMap, wordCount);	// display Words data
	outputNumbers(numMap, numCount);		// display Numbers data
	
	return 0;
}