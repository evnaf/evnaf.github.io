/**
  @file osm.cpp
  @brief Implementation of class Osm.

  This osm.cpp file is where the implentation of the OSM resides. The Implentation invloves taking in the OSM file,
  initializing the class obkect members, and then populating the data members with the results found in the files.

 */

#include "osm.hpp"
#include <regex>
#include <fstream>
#include <iostream>
	using namespace std;

	Osm::Osm(){ //!< The default constructor initializes all member data as 0.
		numNodes = 0;
		numWays = 0;
		numHighways = 0;
		meanLat = 0;
		meanLon = 0;
	};

	//!< Parameterized constructor that takes in the osm filename specified.
	/**
	@param takes in the string of a file name
	*/

	Osm::Osm(const string & irfile){
		numNodes = 0;
		numWays = 0;
		numHighways = 0;
		meanLat = 0;
		meanLon = 0;
		parseNodes(irfile);
		parseWays(irfile);
	};

	Osm::~Osm(){
	};

	/**
	@param takes in the string of a file name
	*/

	void Osm::ParseOsmFile(const string &irfile){ //monday
		parseNodes(irfile);
		parseWays(irfile);
	};

	/** getter for numNodes
		@return reutrns numNodes
	*/

	int Osm::getNumNodes() const{
		return numNodes;
	};

	/** getter for numWays
		@return reutrns numWays
	*/

	int Osm::getNumWays() const{
		return numWays;
	};

	/** getter for numHighways
		@return reutrns numhighways
	*/

	int Osm::getNumHighways() const{
		return numHighways;
	};

	/** getter for meanLat
		@return reutrns numLat
	*/

	double Osm::getMeanLat() const{
		return meanLat;
	};

	/** getter for meanLon
		@return reutrns numLon
	*/

	double Osm::getMeanLon() const{
		return meanLon;
	};

	/**
		ParseNodes will take the input file, parse for a Node type, record the data,
		and proceed to the next line, until end of file.
		@param takes in the string of a file name
	*/
	void Osm::parseNodes(const string &irfile){
		ifstream in;
		int no = 0; //!< Integer no stores the number of nodes, also used for the meanLat and meanLon.
		double la = 0, lo = 0; //!< Storing the latitude and longitude data taken from matches.
		string inp; //!< Stores the current input string line for scrapping.
		smatch nodMatch; //!< An smatch (part of regex) that stores matches for the specified regex search.
		/**
				Regex nod stores our search type, starting the line with <node followed by data until lat and lon.
		*/
		regex nod ("^ <node .+ .+ .+ .+ .+ .+ .+ lat=\"(.+)\" lon=\"(.+)\"/?>$", regex_constants::ECMAScript);

		in.open(irfile.c_str());
		if(!in.eof()){
			while(getline(in,inp,'\n')){
				if(regex_search(inp, nodMatch, nod)){
		          	no++;
				la += stod(nodMatch[1]);
				lo += stod(nodMatch[2]);
				}
			}
		numNodes = no;
		meanLat = la/ no;
		meanLon = lo/ no;
		}
		in.close();
	}

	/**
		Parse ways will re-take in the input file, and parse it for a number of
		Ways tags, indicated by start of line, <way . Then looks for highways
		and stores them in object member data.
		@param takes in the string of a file name
	*/

	void Osm::parseWays(const string &irfile){
		ifstream in;
		int wa = 0, hi = 0; //!< Storage for number of ways, and number of highways
		string inpu,inpu2; //!< Stores the strings used for finding highways
		smatch wayMatch; //!< Smatch (from regex) to store matches for ways
		smatch highMatch; //!< Smatch (from regex) to store matches for highway
		smatch stopMatch; //!< Smatch (from regex) to store matches for last highway
		regex way("^ <way ", regex_constants::ECMAScript); 
		regex high("highway", regex_constants::ECMAScript);
		regex stopsign("^ </way>", regex_constants::ECMAScript);

		in.open(irfile.c_str());
		if(!in.eof()){
			while(getline(in,inpu,'\n')){
				if(regex_search(inpu, wayMatch, way)){
					wa++;
					do{
						getline(in,inpu2,'\n');
						if(regex_search(inpu2, highMatch, high)){
							hi++;
						}
					}while(!regex_search(inpu2,stopMatch,stopsign));
				}
			}
			numWays = wa;
			numHighways = hi;
		}
		in.close();
	}
