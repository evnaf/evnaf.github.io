/**
    @file main.cpp 
    @brief The driver program for class Roman.
    
    The tests for our Roman class implementation are here here.
 */

/** 
    @PROJECT_NAME "Roman Numerals Program" 

    @mainpage "Roman Numerals Program" 
    
    
    This projects goal is very simple, to test the implementation of the Roman class.
    The Roman class is a follows : An Instance Roman stores a number as a Roman numeral
    string. An object of class Roman is initialized either with a Roman numeral string
    or an integer. Member function GetInt() converts the stored Roman numeral string to 
    an integer and returns it. Empty string is considered to be a 0. Member function 
    GetRoman() simply returns the stored Roman numeral string. The overloaded member
    function SetRoman() can take either an integer or a Roman numeral string to update 
    the stored number. Member function IncreaseWith() updates the current number by adding
    the Roman number passed as argument. Non-member function convertIntToRoman() converts
    an integer to a Roman numeral string while convertRomanToInt() converts a Roman numeral
    string to an integer.
 
 */    

#include <iostream>
#include "roman.hpp"

int main () {
    Roman p;
    Roman s(1900);
    std::cout << "Roman for 1900: " << s.GetRoman() << std::endl;

    Roman q("MCMXCV");
    Roman r("MCM");
    p.SetRoman("VII");
    std::cout << p.GetInt() << std::endl;
    std::cout << q.GetInt() << std::endl;
    std::cout << r.GetInt() << std::endl;
}

