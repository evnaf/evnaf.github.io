/**
    @file roman.cpp
    @brief Roman Class implementation.
    
    The Roman Class implementation including Roman member definitions and
    two non-member functions are found in this file. These inplementations 
    will be tested in main.cpp
 */

#include "roman.hpp"
using namespace std;
/* Please add all Roman member definition and two non-member functions in this .cpp file */
int convertRomanToInt(string roman_Str);
string convertIntToRoman(int i);
int romanInt;

      Roman::Roman(){ //!<  Empty Constuctor
	  };
      
      //!< Default constructor for a Roman numeral String called "romanStr" (Empty string)     
      /** 
        \param takes a string as an argument 
	*/

      Roman::Roman(string roman_Str){ 
		romanStr = roman_Str;   
	  };
	
      //!< Default constructor that initializes to 0 (This is the integer default)
      /** 
      	\param takes an int as argument
      */

      Roman::Roman(int roman_Int){
		romanInt = roman_Int;  
		  
	  };
      Roman::~Roman(){ //!< Destructor for the Roman Object
		  romanStr = "";
	      	  romanInt = 0;
		  
	  };
      
      //!< Sets the passed string argument as the Roman Numeral format
      /** 
       \param takes a string as a argument 
       */

      void Roman::SetRoman(string roman_Str){ 
		  romanStr = roman_Str;	
		  
	  };
     
      //!< Sets the passed integer argument as the Number itself
      /** 
       \param takes a int as a argument 
       */

      void Roman::SetRoman(int roman_Int){ 
		  romanInt = roman_Int;
	  };

      string Roman::GetRoman() const{  //!< Returns the string value of the currently stored value
		Roman p;
		p.SetRoman(romanInt);
	      string tmp;
			string y;
            int x = romanInt;
            
			if (x > 0 ){
			y = convertIntToRoman(romanInt);
			return y;
			} else return romanStr;
	      
	  };
      int Roman::GetInt() const{ //!< Returns the integer value of the currently stored value 
	      
	      string tmp;
			int x;
            tmp = typeid(romanStr).name();
    
			if (romanStr[0] != 'M'||'C'||'D'||'L'||'X'||'I'||'V'){
			x = convertRomanToInt(romanStr);
			return x;
			    	} else return romanInt;
		  
	  };
      void Roman::IncreaseWith(const Roman &r){ //!< IncreaseWith(p1) will increase the current roman "" by adding Numeral/Int value
			
	               
	  };
	  
      //!< Will take in a string, and return the integer value
      /** 
       \param takes in a string as an argument
       \return returns the integer of the value
       */

      int convertRomanToInt(string roman_Str){ 

        unsigned int roman_Int = 0;

	    for(unsigned int i = 0; i <= roman_Str.length();i++){
    		
    		switch (roman_Str[i]){
    		  case 'M':
                roman_Int += 1000;
              break;
    		  case 'D':
                roman_Int += 500;
              break;
    		  case 'C':
    		    if(roman_Str[i + 1]=='M'){
    		    roman_Int -= 100;    
    		    }else if(roman_Str[i + 1]=='D'){
    		    roman_Int -= 100;    
    		    }
    		    else{
                roman_Int += 100;
    		    }
    		    
              break;
    		  case 'L':
                roman_Int += 50;
              break;
    		  case 'X':
    		    if(roman_Str[i + 1]=='C'){
    		    roman_Int -= 10;    
    		    }else if(roman_Str[i + 1]=='L'){
    		    roman_Int -= 10;    
    		    }
    		    else{
                roman_Int += 10;
    		    }
              break;
    		  case 'V':
                roman_Int += 5;
              break; 
    		  case 'I':
    		    if(roman_Str[i + 1]=='X'){
    		    roman_Int -= 1;    
    		    }else if(roman_Str[i + 1]=='V'){
    		    roman_Int -= 1;    
    		    }
    		    else{
                roman_Int += 1;
    		    }
              break;              
              default:
                roman_Int += 0;
    		}
   
}
	
	
		return roman_Int; 
	  };

       //!< Will take in a string, and return the integer value
       /** 
       \param takes in a int as an argument
       \return returns the roman numeral of the value
       */

	  string convertIntToRoman(int i){ 
		
		int tmp;
		string roman;
		
		if (i >= 1000){ 
			tmp = i / 1000;
			i = i % 1000;
			for (int j = 1; j <= tmp;j++){
				roman += "M"; 
				}
			tmp = 0;
		}
		if (i >= 900){
			tmp = i / 900;
			i = i % 900;
			for (int j = 1; j <= tmp;j++){
				roman += "CM"; 
				}
			tmp = 0;
		}    
		if (i >= 500){
			tmp = i / 500;
			i = i % 500;
			for (int t = 1; t <= tmp;t++){
				roman += "D"; 
				}
				tmp = 0;
			
		}
		if (i >= 400){
			tmp = i / 400;
			i = i % 400;
			for (int j = 1; j <= tmp;j++){
				roman += "CD"; 
				}
			tmp = 0;
		}    
		if (i >= 100){
			tmp = i / 100;
			i = i % 100;
			for (int e = 1; e <= tmp;e++){
				roman += "C"; 
				}
				tmp = 0;
			
		}
		if (i >= 90){
			tmp = i / 90;
			i = i % 90;
			for (int j = 1; j <= tmp;j++){
				roman += "XC"; 
				}
			tmp = 0;
		}    		
		if (i >= 50){
			tmp = i / 50;
			i = i % 50;
			for (int u = 1; u <= tmp;u++){
				roman += "L"; 
				}
				tmp = 0;
			
		}
		if (i >= 40){
			tmp = i / 40;
			i = i % 40;
			for (int j = 1; j <= tmp;j++){
				roman += "XL"; 
				}
			tmp = 0;
		}    
		if (i >= 10){
			tmp = i / 10;
			i = i % 10;
			for (int z = 1; z <= tmp;z++){
				roman += "X"; 
				}
				tmp = 0;
			
		}       
		if (i == 9){
			roman += "IX"; 
			  
		}else if (i >= 5){
			tmp = i % 5;
			roman += "V";
			
			for (int q = 1; q <= tmp;q++){
				roman += "I";
			}
				tmp = 0;
				
		}else if (i == 4){
		roman += "IV";
		}else if (i >= 1){
			tmp = i;
			
			for (int p = 1; p <= tmp;p++){
				roman += "I"; 
			}
				tmp = 0;
				
		}   
			return roman;  
		  };
	  
